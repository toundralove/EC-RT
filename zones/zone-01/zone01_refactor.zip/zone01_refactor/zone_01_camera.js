/* =====================================================
   EC@RT — Zone 01 Poster
   CameraEngine : zoom / pan / bounds / reset
   Règle absolue : ce module ne gère PAS l'esthétique.
===================================================== */

window.Zone01Camera = (() => {
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  const smoothstep = (a, b, x) => {
    const t = clamp((x - a) / (b - a), 0, 1);
    return t * t * (3 - 2 * t);
  };

  function createCamera(viewer, img, options = {}) {
    const config = {
      maxZoomMultiplier: 36,
      zoomSpeed: 0.00115,
      zoomSmooth: 0.16,
      panSmooth: 0.18,
      resetThreshold: 1.01,
      ...options
    };

    const state = {
      scale: 1,
      targetScale: 1,
      minScale: 1,
      maxScale: 1,

      x: 0,
      y: 0,
      targetX: 0,
      targetY: 0,

      pointerX: 0,
      pointerY: 0,

      lastMoveTime: performance.now(),
      lastTargetScale: 1,
      lastZoomVelocity: 0,

      dragging: false,
      dragStartX: 0,
      dragStartY: 0,

      initialized: false
    };

    const pointers = new Map();

    function computeScales() {
      const rect = viewer.getBoundingClientRect();
      if (!img.naturalWidth || !img.naturalHeight) return;

      // Math.min = image entière visible au dézoom maximal.
      state.minScale = Math.min(
        rect.width / img.naturalWidth,
        rect.height / img.naturalHeight
      );

      state.maxScale = state.minScale * config.maxZoomMultiplier;
    }

    function depth() {
      if (state.maxScale === state.minScale) return 0;

      return clamp(
        Math.log(state.scale / state.minScale) /
          Math.log(state.maxScale / state.minScale),
        0,
        1
      );
    }

    function transform() {
      return `translate(-50%, -50%) translate3d(${state.x}px, ${state.y}px, 0) scale(${state.scale})`;
    }

    function boundsFor(scale = state.targetScale) {
      const rect = viewer.getBoundingClientRect();
      const imageW = img.naturalWidth * scale;
      const imageH = img.naturalHeight * scale;

      return {
        maxX: Math.max(0, (imageW - rect.width) / 2),
        maxY: Math.max(0, (imageH - rect.height) / 2)
      };
    }

    function clampTarget() {
      const bounds = boundsFor(state.targetScale);

      state.targetX = clamp(state.targetX, -bounds.maxX, bounds.maxX);
      state.targetY = clamp(state.targetY, -bounds.maxY, bounds.maxY);

      // Recentrage uniquement quand on est vraiment au minimum.
      if (state.targetScale <= state.minScale * config.resetThreshold) {
        state.targetScale = state.minScale;
        state.targetX = 0;
        state.targetY = 0;
      }
    }

    function zoomAt(clientX, clientY, factor) {
      const rect = viewer.getBoundingClientRect();
      const localX = clientX - rect.left - rect.width / 2;
      const localY = clientY - rect.top - rect.height / 2;

      const oldScale = state.targetScale;
      const newScale = clamp(oldScale * factor, state.minScale, state.maxScale);
      const ratio = newScale / oldScale;

      state.targetScale = newScale;
      state.targetX = localX - (localX - state.targetX) * ratio;
      state.targetY = localY - (localY - state.targetY) * ratio;

      state.pointerX = localX;
      state.pointerY = localY;

      clampTarget();
    }

    function reset() {
      state.scale = state.minScale;
      state.targetScale = state.minScale;
      state.x = 0;
      state.y = 0;
      state.targetX = 0;
      state.targetY = 0;
    }

    function update(dtFactor) {
      state.scale += (state.targetScale - state.scale) * config.zoomSmooth * dtFactor;
      state.x += (state.targetX - state.x) * config.panSmooth * dtFactor;
      state.y += (state.targetY - state.y) * config.panSmooth * dtFactor;

      const zoomVelocity = Math.abs(state.targetScale - state.lastTargetScale) / state.maxScale;
      state.lastZoomVelocity = zoomVelocity;
      state.lastTargetScale = state.targetScale;

      clampTarget();
    }

    function screenToImageNorm(screenX = state.pointerX, screenY = state.pointerY) {
      return {
        x: clamp(0.5 + (screenX - state.x) / (img.naturalWidth * state.scale), 0, 1),
        y: clamp(0.5 + (screenY - state.y) / (img.naturalHeight * state.scale), 0, 1)
      };
    }

    function imageNormToScreen(nx, ny) {
      return {
        x: (nx - 0.5) * img.naturalWidth * state.scale + state.x,
        y: (ny - 0.5) * img.naturalHeight * state.scale + state.y
      };
    }

    function bindEvents() {
      viewer.addEventListener(
        "wheel",
        event => {
          event.preventDefault();
          const factor = Math.exp(-event.deltaY * config.zoomSpeed);
          zoomAt(event.clientX, event.clientY, factor);
        },
        { passive: false }
      );

      viewer.addEventListener("pointerdown", event => {
        pointers.set(event.pointerId, event);

        const rect = viewer.getBoundingClientRect();
        state.pointerX = event.clientX - rect.left - rect.width / 2;
        state.pointerY = event.clientY - rect.top - rect.height / 2;
        state.lastMoveTime = performance.now();

        if (pointers.size === 1) {
          state.dragging = true;
          state.dragStartX = event.clientX - state.targetX;
          state.dragStartY = event.clientY - state.targetY;
          viewer.classList.add("is-dragging");
          viewer.setPointerCapture(event.pointerId);
        }
      });

      viewer.addEventListener("pointermove", event => {
        if (!pointers.has(event.pointerId)) return;
        pointers.set(event.pointerId, event);

        const rect = viewer.getBoundingClientRect();
        const localX = event.clientX - rect.left - rect.width / 2;
        const localY = event.clientY - rect.top - rect.height / 2;

        const moved = Math.hypot(localX - state.pointerX, localY - state.pointerY);
        state.pointerX = localX;
        state.pointerY = localY;

        if (moved > 2.5) state.lastMoveTime = performance.now();

        if (pointers.size === 1 && state.dragging) {
          state.targetX = event.clientX - state.dragStartX;
          state.targetY = event.clientY - state.dragStartY;
          clampTarget();
        }

        if (pointers.size === 2) {
          const [a, b] = [...pointers.values()];
          const distance = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);

          if (!viewer.__zone01PinchDistance) {
            viewer.__zone01PinchDistance = distance;
            return;
          }

          const factor = distance / viewer.__zone01PinchDistance;
          viewer.__zone01PinchDistance = distance;

          zoomAt((a.clientX + b.clientX) / 2, (a.clientY + b.clientY) / 2, factor);
        }
      });

      function endPointer(event) {
        pointers.delete(event.pointerId);

        if (viewer.hasPointerCapture(event.pointerId)) {
          viewer.releasePointerCapture(event.pointerId);
        }

        if (pointers.size === 0) {
          state.dragging = false;
          viewer.classList.remove("is-dragging");
          viewer.__zone01PinchDistance = null;
        }

        if (pointers.size < 2) viewer.__zone01PinchDistance = null;
      }

      viewer.addEventListener("pointerup", endPointer);
      viewer.addEventListener("pointercancel", endPointer);
      viewer.addEventListener("pointerleave", endPointer);
      viewer.addEventListener("dblclick", reset);

      window.addEventListener("resize", () => {
        const currentDepth = depth();
        computeScales();

        state.targetScale =
          state.minScale * Math.pow(state.maxScale / state.minScale, currentDepth);
        state.scale = state.targetScale;

        clampTarget();
      });
    }

    function init() {
      if (state.initialized) return;
      state.initialized = true;

      computeScales();
      reset();
      bindEvents();
    }

    return {
      state,
      config,
      clamp,
      smoothstep,
      init,
      update,
      reset,
      depth,
      transform,
      screenToImageNorm,
      imageNormToScreen
    };
  }

  return { createCamera };
})();
