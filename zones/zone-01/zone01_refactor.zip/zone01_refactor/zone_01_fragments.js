/* =====================================================
   FragmentsSystem : strates, fragments flottants, zones sensibles
   Règle : ne modifie jamais la caméra.
===================================================== */

window.Zone01Fragments = (() => {
  const SENSITIVE_FRAGMENTS = [
    { id: "bord", x: 0.23, y: 0.26, radius: 0.13, minDepth: 0.16, requires: [], text: "un bord insiste" },
    { id: "surface", x: 0.52, y: 0.18, radius: 0.12, minDepth: 0.22, requires: ["bord"], text: "la surface commence à parler" },
    { id: "corps", x: 0.48, y: 0.52, radius: 0.15, minDepth: 0.25, requires: [], text: "rester assez longtemps" },
    { id: "strate", x: 0.68, y: 0.63, radius: 0.12, minDepth: 0.33, requires: ["corps"], text: "une strate répond" },
    { id: "memoire", x: 0.38, y: 0.76, radius: 0.14, minDepth: 0.42, requires: ["surface", "strate"], text: "l’archive se recompose" }
  ];

  function createFragments(viewer, img, camera, memory, atmosphere, options = {}) {
    const config = {
      layerCount: 3,
      floatingFragmentCount: 8,
      dwellTime: 1400,
      stillDelay: 260,
      ...options
    };

    const layers = [];
    const floating = [];
    const sensitive = [];

    function makeLayer(i) {
      const layer = img.cloneNode(true);
      layer.removeAttribute("id");
      layer.className = "layer-image";
      layer.setAttribute("aria-hidden", "true");
      viewer.appendChild(layer);

      layers.push({
        el: layer,
        scaleOffset: 1.12 + i * 0.28,
        driftX: (Math.random() - 0.5) * 160,
        driftY: (Math.random() - 0.5) * 160,
        phase: Math.random() * Math.PI * 2
      });
    }

    function randomFloating(fragment) {
      return Object.assign(fragment, {
        screenX: 10 + Math.random() * 80,
        screenY: 10 + Math.random() * 80,
        sourceX: (Math.random() - 0.5) * 1100,
        sourceY: (Math.random() - 0.5) * 1100,
        size: 90 + Math.random() * 120,
        appearA: 0.1 + Math.random() * 0.22,
        appearB: 0.34 + Math.random() * 0.22,
        speed: 0.38 + Math.random() * 0.36,
        phase: Math.random() * Math.PI * 2,
        roundness: 20 + Math.random() * 42
      });
    }

    function makeFloating() {
      const el = img.cloneNode(true);
      el.removeAttribute("id");
      el.className = "memory-fragment";
      el.setAttribute("aria-hidden", "true");
      viewer.appendChild(el);
      floating.push(randomFloating({ el }));
    }

    function makeSensitive(data) {
      const el = document.createElement("div");
      el.className = "sensitive-fragment";

      const trace = document.createElement("div");
      trace.className = "sensitive-fragment__trace";

      const label = document.createElement("div");
      label.className = "sensitive-fragment__label";
      label.textContent = data.text;

      el.appendChild(trace);
      el.appendChild(label);
      viewer.appendChild(el);

      const fragment = {
        ...data,
        el,
        dwell: 0,
        found: memory.has(data.id)
      };

      if (fragment.found) el.classList.add("is-found");
      sensitive.push(fragment);
    }

    function requirementsMet(fragment) {
      return fragment.requires.every(id => memory.has(id));
    }

    function discover(fragment) {
      if (fragment.found) return;

      fragment.found = true;
      memory.add(fragment.id);
      fragment.el.classList.add("is-found");

      atmosphere.showMessage(fragment.text, 2600);
      atmosphere.pulse();
    }

    function updateLayers(time, p) {
      const { smoothstep } = camera;
      const state = camera.state;

      layers.forEach((layer, i) => {
        const appear =
          smoothstep(0.12 + i * 0.08, 0.48 + i * 0.08, p) *
          (1 - smoothstep(0.72, 0.94, p));

        const breathe = Math.sin(time * 0.00035 + layer.phase) * 18;

        layer.el.style.transform = `
          translate(-50%, -50%)
          translate3d(${state.x * 0.66 + layer.driftX + breathe}px, ${state.y * 0.66 + layer.driftY - breathe}px, 0)
          scale(${state.scale * layer.scaleOffset})
        `;

        layer.el.style.opacity = appear * 0.12;
        layer.el.style.filter = `blur(${6 - appear * 4}px)`;
        layer.el.style.clipPath = `circle(${20 + appear * 34}% at ${45 + i * 8}% ${50 - i * 6}%)`;
      });
    }

    function updateFloating(time, p) {
      const { smoothstep } = camera;
      const state = camera.state;
      const rect = viewer.getBoundingClientRect();

      floating.forEach(fragment => {
        const appear =
          smoothstep(fragment.appearA, fragment.appearB, p) *
          (1 - smoothstep(0.66, 0.9, p));

        const driftX =
          Math.sin(time * 0.001 * fragment.speed + fragment.phase) *
          30 *
          (1 - p * 0.45);

        const driftY =
          Math.cos(time * 0.001 * fragment.speed + fragment.phase) *
          26 *
          (1 - p * 0.45);

        const x = rect.width * (fragment.screenX / 100) - rect.width / 2 + driftX;
        const y = rect.height * (fragment.screenY / 100) - rect.height / 2 + driftY;

        fragment.el.style.width = `${fragment.size}px`;
        fragment.el.style.height = `${fragment.size * 0.72}px`;
        fragment.el.style.transform = `translate(-50%, -50%) translate3d(${x}px, ${y}px, 0) scale(${0.88 + appear * 0.64})`;
        fragment.el.style.opacity = appear * 0.3;
        fragment.el.style.borderRadius = `${fragment.roundness}% ${80 - fragment.roundness}% ${54 + fragment.roundness * 0.3}% ${70 - fragment.roundness * 0.2}%`;
        fragment.el.style.objectFit = "none";
        fragment.el.style.objectPosition = `
          calc(50% + ${fragment.sourceX + state.x * 0.16 - state.pointerX * 0.38}px)
          calc(50% + ${fragment.sourceY + state.y * 0.16 - state.pointerY * 0.38}px)
        `;
        fragment.el.style.filter = `blur(${(1 - appear) * 5}px) contrast(${1.02 + appear * 0.12}) brightness(${0.84 + appear * 0.1}) saturate(0.82)`;
      });
    }

    function updateSensitive(time, frameDelta, p, atmosphereState) {
      const pointer = camera.screenToImageNorm();
      const isStill = time - camera.state.lastMoveTime > config.stillDelay;
      const punished = atmosphereState && atmosphereState.punished;

      sensitive.forEach(fragment => {
        const available = requirementsMet(fragment);
        const dx = pointer.x - fragment.x;
        const dy = pointer.y - fragment.y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        const active =
          distance < fragment.radius &&
          p >= fragment.minDepth &&
          isStill &&
          available &&
          !punished;

        if (active) fragment.dwell += frameDelta;
        else fragment.dwell *= 0.92;

        const dwellRatio = camera.clamp(fragment.dwell / config.dwellTime, 0, 1);
        if (dwellRatio >= 1) discover(fragment);

        const screen = camera.imageNormToScreen(fragment.x, fragment.y);

        const opacity = fragment.found
          ? 0.48
          : active
          ? 0.26 + dwellRatio * 0.62
          : available && p >= fragment.minDepth
          ? 0.07
          : 0.015;

        fragment.el.style.transform = `translate(-50%, -50%) translate3d(${screen.x}px, ${screen.y}px, 0) scale(${0.86 + p * 1.05 + dwellRatio * 0.24})`;
        fragment.el.style.opacity = opacity;
        fragment.el.style.width = `${130 + p * 150}px`;
        fragment.el.style.height = `${86 + p * 92}px`;
        fragment.el.style.setProperty("--dwell", dwellRatio.toFixed(3));
        fragment.el.classList.toggle("is-waiting", active && !fragment.found);
        fragment.el.classList.toggle("is-locked", !available);
      });
    }

    function update(time, frameDelta, atmosphereState) {
      const p = camera.depth();
      updateLayers(time, p);
      updateFloating(time, p);
      updateSensitive(time, frameDelta, p, atmosphereState);
    }

    function init() {
      for (let i = 0; i < config.layerCount; i++) makeLayer(i);
      for (let i = 0; i < config.floatingFragmentCount; i++) makeFloating();
      SENSITIVE_FRAGMENTS.forEach(makeSensitive);
    }

    return {
      init,
      update,
      totalSensitive: SENSITIVE_FRAGMENTS.length
    };
  }

  return { createFragments };
})();
