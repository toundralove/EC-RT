/* =====================================================
   MemorySystem : mémoire locale des fragments trouvés
===================================================== */

window.Zone01Memory = (() => {
  function createMemory(storageKey) {
    const found = new Set(load());

    function load() {
      try {
        return JSON.parse(localStorage.getItem(storageKey)) || [];
      } catch {
        return [];
      }
    }

    function save() {
      localStorage.setItem(storageKey, JSON.stringify([...found]));
    }

    function has(id) {
      return found.has(id);
    }

    function add(id) {
      found.add(id);
      save();
    }

    function ratio(total) {
      if (!total) return 0;
      return found.size / total;
    }

    function clear() {
      found.clear();
      save();
    }

    return { found, has, add, ratio, clear };
  }

  return { createMemory };
})();
