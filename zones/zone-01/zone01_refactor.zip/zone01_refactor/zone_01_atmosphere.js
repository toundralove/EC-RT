/* =====================================================
   AtmosphereSystem : voile / flou / phrase / punition douce
   Règle : ne modifie jamais scale, x, y.
===================================================== */

window.Zone01Atmosphere = (() => {
  function createAtmosphere(viewer, img, audio, camera, options = {}) {
    const config = {
      maxMiddleBlur: 2.4,
      veilIntensity: 0.72,
      audioInfluence: 0.1,
      fastZoomThreshold: 0.13,
      fastZoomPenalty: 600,
      ...options
    };

    let punishedUntil = 0;
    let message = "";
    let messageUntil = 0;

    const whisper = document.createElement("div");
    whisper.className = "archive-whisper";
    viewer.appendChild(whisper);

    function showMessage(text, duration = 2200) {
      message = text;
      messageUntil = performance.now() + duration;
    }

    function pulse() {
      viewer.classList.add("archive-pulse");
      window.setTimeout(() => viewer.classList.remove("archive-pulse"), 700);
    }

    function updateMessage() {
      const visible = performance.now() < messageUntil;
      whisper.textContent = visible ? message : "";
      whisper.classList.toggle("is-visible", visible);
    }

    function update(time, memoryRatio = 0) {
      const p = camera.depth();
      const { smoothstep, clamp } = camera;
      const state = camera.state;

      const velocity = state.lastZoomVelocity;
      const zoomingIn = state.targetScale > state.lastTargetScale;

      if (zoomingIn && velocity > config.fastZoomThreshold) {
        punishedUntil = time + config.fastZoomPenalty;
        showMessage("trop vite : l’image se retire", 900);
      }

      const punished = time < punishedUntil;

      const middleBlur =
        smoothstep(0.08, 0.32, p) *
        (1 - smoothstep(0.56, 0.78, p)) *
        config.maxMiddleBlur;

      const audioFactor =
        audio && !audio.paused
          ? (Math.sin(time * 0.0016) * 0.5 + 0.5) * config.audioInfluence
          : 0;

      const veil =
        smoothstep(0.08, 0.36, p) *
          (1 - smoothstep(0.62, 0.86, p)) *
          config.veilIntensity +
        audioFactor +
        (punished ? 0.12 : 0);

      viewer.style.setProperty("--depth", p.toFixed(3));
      viewer.style.setProperty("--veil", clamp(veil, 0, 0.9).toFixed(3));
      viewer.style.setProperty("--memory", memoryRatio.toFixed(3));

      img.style.transform = camera.transform();
      img.style.filter = `
        blur(${middleBlur + (punished ? 1.4 : 0)}px)
        contrast(${1 - veil * 0.08 + memoryRatio * 0.04})
        brightness(${1 - veil * 0.04 + memoryRatio * 0.03})
        saturate(${1 - veil * 0.1})
      `;

      updateMessage();

      return { punished };
    }

    return { update, showMessage, pulse };
  }

  return { createAtmosphere };
})();
