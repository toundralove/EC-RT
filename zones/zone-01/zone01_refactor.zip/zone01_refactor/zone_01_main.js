/* =====================================================
   EC@RT — Zone 01 Poster
   Main : orchestre les modules sans mélanger leurs rôles.
===================================================== */

(() => {
  const viewer = document.getElementById("imageViewer");
  const img = document.getElementById("zoomImage");
  const audio = document.getElementById("posterAudio");

  if (!viewer || !img) return;

  const memory = Zone01Memory.createMemory("ecart_zone01_fragments_found_v2");
  const camera = Zone01Camera.createCamera(viewer, img, {
    maxZoomMultiplier: 36,
    zoomSpeed: 0.00115,
    zoomSmooth: 0.16,
    panSmooth: 0.18,
    resetThreshold: 1.01
  });

  const atmosphere = Zone01Atmosphere.createAtmosphere(viewer, img, audio, camera, {
    maxMiddleBlur: 2.4,
    veilIntensity: 0.72,
    audioInfluence: 0.1,
    fastZoomThreshold: 0.13,
    fastZoomPenalty: 600
  });

  const fragments = Zone01Fragments.createFragments(
    viewer,
    img,
    camera,
    memory,
    atmosphere,
    {
      layerCount: 3,
      floatingFragmentCount: 8,
      dwellTime: 1400,
      stillDelay: 260
    }
  );

  let initialized = false;
  let lastTime = 0;

  function animate(time) {
    const frameDelta = lastTime ? time - lastTime : 16.666;
    const dtFactor = Math.min(1.8, frameDelta / 16.666);
    lastTime = time;

    camera.update(dtFactor);

    const memoryRatio = memory.ratio(fragments.totalSensitive);
    const atmosphereState = atmosphere.update(time, memoryRatio);

    fragments.update(time, frameDelta, atmosphereState);

    requestAnimationFrame(animate);
  }

  function init() {
    if (initialized) return;
    initialized = true;

    camera.init();
    fragments.init();

    atmosphere.showMessage("zoomer, attendre, perdre, retrouver", 2600);
    requestAnimationFrame(animate);
  }

  img.addEventListener("load", init);

  if (img.complete && img.naturalWidth > 0) {
    init();
  }
})();
